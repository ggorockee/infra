helm install my-routes ./traefik-routes
