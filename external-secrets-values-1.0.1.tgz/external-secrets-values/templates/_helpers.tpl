{{- define "ssm.name" -}}
{{- default "aws-ssm-store" .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{- define "ssm.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{- define "ssm.aws.service" -}}
{{- with .Values.clusterSecretStore }}
  {{- default "ParameterStore" .aws.service }}
{{- else }}
  ParameterStore
{{- end }}
{{- end }}

{{- define "ssm.aws.region" -}}
{{- with .Values.clusterSecretStore }}
  {{- default "ap-northeast-2" .aws.region }}
{{- else }}
  ap-northeast-2
{{- end }}
{{- end }}

{{- define "ssm.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "ssm.labels" -}}
helm.sh/chart: {{ include "ssm.chart" . }}
{{ include "ssm.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "ssm.selectorLabels" -}}
app.kubernetes.io/name: {{ include "ssm.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}