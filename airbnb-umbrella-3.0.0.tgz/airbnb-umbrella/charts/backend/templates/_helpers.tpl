{{/*
Expand the name of the chart.
*/}}
{{- define "backend.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "backend.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "backend.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "backend.labels" -}}
helm.sh/chart: {{ include "backend.chart" . }}
{{ include "backend.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "backend.selectorLabels" -}}
app.kubernetes.io/name: {{ include "backend.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "backend.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "backend.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}



{{- define "backend.secret.name" -}}
{{ include "backend.fullname" .}}-secret
{{- end -}}

{{- define "backend.secret.data" -}}
CACHE_URL: bWVtY2FjaGU6Ly8xMjcuMC4wLjE6MTEyMTEsMTI3LjAuMC4xOjExMjEyLDEyNy4wLjAuMToxMTIxMw==
DATABASE_URL: cHNxbDovL3VzZXI6dW4tZ2l0aHViYmVkcGFzc3dvcmRAMTI3LjAuMC4xOjg0NTgvZGF0YWJhc2U=
DEBUG: b2Zm
DJANGO_ALLOWED_HOSTS: KiwxMjcuMC4wLjE=
KAKAO_CLIENT_ID: YzY1YmExMzFkNDQ5N2M4Mzg5ZTA3OGNmYmU1OTQ2OWU=
POSTGRES_DB: YWlyYm5iLWRldg==
POSTGRES_HOST: YWlyYm5iLXVtYnJlbGxhLWRldi1wb3N0Z3Jlc3FsLmFpcmJuYi1kZXYuc3ZjLmNsdXN0ZXIubG9jYWw=
POSTGRES_PASSWORD: Z2dvcm9ja2VlITE=
POSTGRES_PORT: NTQzMg==
POSTGRES_USER: Z2dvcm9ja2Vl
REDIS_URL: cmVkaXNjYWNoZTovLzEyNy4wLjAuMTo2Mzc5LzE/Y2xpZW50X2NsYXNzPWRqYW5nb19yZWRpcy5jbGllbnQuRGVmYXVsdENsaWVudCZwYXNzd29yZD11bmdpdGh1YmJlZC1zZWNyZXQ=
SECRET_KEY: ZGphbmdvLWluc2VjdXJlLSY3Xj1xeTF0bm11KEBrNDlwaGdvKzJubnJ5ZWZrb24pb2E0cG0teiF6ZiVodit6PXJm
SQLITE_URL: c3FsaXRlOi8vL215LWxvY2FsLXNxbGl0ZS5kYg==
{{- end -}}
